package arr_exc;

public class Exc01 {
	public static void main(String[] args) {
//		 int[] arr1[]; //int[][] arr1 과 같다
//		 
//		 int[] arr2 = {1,2,3,};
//		 int[] arr3 = new int[5];
//		 int[] arr4 = new int[]{1,2,3,4,5}; //뒤에 초기화할때는 배열안에 공간을 미리 만들지않는다
//		 int[] arr5[];
//		 
//		 int[] arr6[] = new int[3][];
	}
}
